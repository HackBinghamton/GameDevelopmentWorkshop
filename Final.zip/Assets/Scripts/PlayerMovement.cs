using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
	[SerializeField]
	private Rigidbody rb;

	[SerializeField]
	private float speed;

	private GameManager gameManager;

	private bool isPressingRight = false;
	private bool isPressingLeft = false;
	private bool isPressingUp = false;
	private bool isPressingDown = false;


	// Start is called before the first frame update
	void Start()
	{
		rb = GetComponent<Rigidbody>();
		gameManager = FindObjectOfType<GameManager>();
	}

	// Update is called once per frame
	void Update() 
	{
		CheckInput();
		CheckYPosition();
	}

	void FixedUpdate() 
	{
		ApplyForces();
	}

	private void ApplyForces()
	{
		if (isPressingRight) rb.AddForce(speed, 0f, 0f);
		if (isPressingLeft) rb.AddForce(-speed, 0f, 0f);
		if (isPressingUp) rb.AddForce(0f, 0f, speed);
		if (isPressingDown) rb.AddForce(0f, 0f, -speed);
	}

	private void CheckInput()
	{
		if (Input.GetKey(KeyCode.RightArrow)) isPressingRight = true;
		else isPressingRight = false;

		if (Input.GetKey(KeyCode.LeftArrow)) isPressingLeft = true;
		else isPressingLeft = false;

		if (Input.GetKey(KeyCode.UpArrow)) isPressingUp = true;
		else isPressingUp = false;

		if (Input.GetKey(KeyCode.DownArrow)) isPressingDown = true;
		else isPressingDown = false;
	}

	private void CheckYPosition()
	{
		if(transform.position.y < -1f)
		{
			gameManager.GameLose();
		}
	}
}
