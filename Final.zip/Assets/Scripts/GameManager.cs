using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    [SerializeField]
    private TextMeshProUGUI GameOverText;

	[SerializeField]
	private TextMeshProUGUI ScoreText;
	private int score;

	void Start()
	{
		score = FindObjectsOfType<Collectable>().Length;
		ScoreText.text = score.ToString();
	}

	public void Score()
	{
		score--;
		ScoreText.text = score.ToString();
		if(score == 0)
		{
			GameWin();
		}
	}

    public void GameWin()
	{
		GameOverText.text = "You Win!";
		GameOverText.gameObject.SetActive(true);
		FindObjectOfType<PlayerMovement>().enabled = false;
		Invoke(nameof(LoadNextScene), 2f);
	}

    public void GameLose()
	{
		GameOverText.text = "You Lose :(";
		GameOverText.gameObject.SetActive(true);
		FindObjectOfType<PlayerMovement>().enabled = false;
		Invoke(nameof(ReloadScene), 2f);

	}

	private void LoadNextScene()
	{
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
	}

	private void ReloadScene()
	{
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
	}
}
